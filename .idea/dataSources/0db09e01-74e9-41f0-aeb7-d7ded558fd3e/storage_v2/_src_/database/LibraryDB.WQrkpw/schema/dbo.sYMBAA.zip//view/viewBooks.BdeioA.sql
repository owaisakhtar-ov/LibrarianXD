
CREATE VIEW [dbo].[viewBooks] AS
SELECT t1.Book_UniqueID AS ID,t1.Book_Name AS Name,t1.Book_Edition AS Edition,t1.Book_Language AS [Language],t1.Book_Writer AS Writer,t1.Book_Qualtity AS Quantity ,t2.Genre_Name AS Genre
FROM tbl_Book t1
INNER JOIN tbl_Genre t2 ON t1.GerneID = t2.Genre_ID
go

