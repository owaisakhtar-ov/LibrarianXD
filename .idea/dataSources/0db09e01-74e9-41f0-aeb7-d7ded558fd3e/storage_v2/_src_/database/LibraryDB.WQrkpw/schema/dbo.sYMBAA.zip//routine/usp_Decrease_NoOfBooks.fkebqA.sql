CREATE PROCEDURE usp_Decrease_NoOfBooks(@id AS int)
	AS
		UPDATE tbl_Book
		SET Book_Qualtity = Book_Qualtity-1
		Where Book_ID = @id
go

