CREATE VIEW viewGenre
AS
	SELECT t1.Genre_UniqueID AS ID, t1.Genre_Name AS [Name]
	FROM tbl_Genre t1
go

