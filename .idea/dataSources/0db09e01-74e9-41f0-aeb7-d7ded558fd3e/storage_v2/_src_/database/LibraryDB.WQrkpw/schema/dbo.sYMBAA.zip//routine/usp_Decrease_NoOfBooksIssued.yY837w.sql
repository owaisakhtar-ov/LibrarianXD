CREATE PROCEDURE usp_Decrease_NoOfBooksIssued(@id AS int)
	AS
		UPDATE tbl_Student
		SET Student_No_Of_Books_issued = Student_No_Of_Books_issued-1
		Where Student_ID = @id
go

