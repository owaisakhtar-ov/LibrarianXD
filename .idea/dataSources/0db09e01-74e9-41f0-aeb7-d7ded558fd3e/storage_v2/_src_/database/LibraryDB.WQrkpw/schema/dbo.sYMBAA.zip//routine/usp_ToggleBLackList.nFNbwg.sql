CREATE PROCEDURE usp_ToggleBLackList @id AS int
AS
	UPDATE tbl_Student
	SET Student_isBlackList = Student_isBlackList ^ 1
	WHERE Student_ID = @id;
go

