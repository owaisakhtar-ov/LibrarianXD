CREATE VIEW viewStudent AS
SELECT t1.Student_UniqueID AS ID,t1.Student_Name AS [Name],t1.Student_Contact AS Contact,t1.Student_Email AS Email,t1.Student_Address AS [Address],t1.Student_RegisterDate AS [Registration Date],t1.Student_No_Of_Books_issued AS [No. Of Books Issued], CASE WHEN t1.Student_isBlackList = 1 THEN 'Yes' ELSE 'No' END AS Blacklisted  --t1.Student_isBlackList [Blacklisted()]
	FROM tbl_Student t1


go

