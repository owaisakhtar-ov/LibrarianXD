CREATE VIEW viewStaff AS
SELECT t1.Staff_UniqueID AS ID,t1.Staff_Name AS [Name],t1.Staff_Contact AS Contact,t1.Staff_Designation AS Designation
	FROM tbl_Staff t1
go

