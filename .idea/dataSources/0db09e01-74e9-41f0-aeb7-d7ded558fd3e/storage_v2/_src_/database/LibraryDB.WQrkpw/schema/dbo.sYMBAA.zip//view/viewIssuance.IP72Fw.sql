CREATE VIEW viewIssuance AS
	SELECT t1.Issue_UniqueID AS ID,t1.Issue_OnDate AS [Issue Date],t1.Issue_TillDate AS [Issue Till],t3.Student_UniqueID AS [Student ID],t3.Student_Name AS [Student Name],t2.Book_UniqueID AS [Book ID],t2.Book_Name AS [Book Name],t4.Staff_UniqueID AS [Staff ID],t4.Staff_Name AS[Staff Name]
	FROM tbl_Issuance t1
	INNER JOIN tbl_Book t2 ON (t1.Issue_Book = t2.Book_ID)
	INNER JOIN tbl_Student t3 ON (t1.Issue_To = t3.Student_ID)
	INNER JOIN tbl_Staff t4 ON (t1.Issue_By = t4.Staff_ID)
go

