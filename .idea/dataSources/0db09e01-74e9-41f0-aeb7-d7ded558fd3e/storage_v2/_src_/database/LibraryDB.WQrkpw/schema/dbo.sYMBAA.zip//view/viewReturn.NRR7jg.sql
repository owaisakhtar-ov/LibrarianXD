CREATE VIEW viewReturn AS
	SELECT t1.Return_UniqueID AS ID,t3.Issue_OnDate AS [Issue Date],t1.Return_Date AS [Return Date],t3.Issue_TillDate AS [Issue Till],t3.Issue_UniqueID AS [Issue ID],t2.Staff_Name[Recieved By],t2.Staff_UniqueID AS [Staff ID]
	FROM tbl_Return t1
	INNER JOIN tbl_Staff t2 ON (t1.Recieved_By = t2.Staff_ID)
	INNER JOIN tbl_Issuance t3 ON(t1.Return_Referece = t3.Issue_ID)
go

